/*
MATHEMATICAL OPERATORS
+ for addition
- for subtration
/ for division
* for multiplication
++ for increment by 1
-- for increment by 1
+=2 increase by 2
-=2 increase by 2
% shows the reminder after division

*/

document.write('<h2>Mathematical Operation</h2>')
var a =10
var b = 2
console.log(a+b)
console.log(a-b)
console.log(a/b)
console.log(a*b)
console.log(a%b)
//console.log(a-=2)